package brainpackage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;


public class Selector{
	 	String baseUrl = "https://demoqa.com/";
	    String driverPath = "/home/luis/eclipse-workspace/ChallengeBrainTesting/files/chromedriver";
	    WebDriver driver = new ChromeDriver(); 
	  
	
  @Test(priority = 0)
  public void selectorTest() throws IOException {
		 
	  System.setProperty("chromedriver", driverPath);
      driver.get(baseUrl);
      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
      String option;   
      System.out.println("Por favor seleciona una opción para ingresar:\\n 1. Elements \\n 2. Forms\\n3. Alerts,Frames Windows"
      		+ "\\n 4. Widgets  \\n 5. Interactions \\n 6. Book Store Application");
      option= br.readLine();  
      int number = Integer.parseInt(option);
      switch (number) {
      case 1 :
          driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]")).click();
          break;
      case 2 :
          driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[3]")).click();
          break;
      case 3 :
          driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[3]/h5[1]")).click();
          break;
      case  4  :
          driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[4]/div[1]/div[3]")).click();
          break;
      case 5 :
          driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[5]/div[1]/div[3]")).click();
          break;
      case 6 :
          driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[6]/div[1]/div[3]/h5[1]")).click();
          break;
     
      }
      
      driver.close();
	
  }

  @Test(priority = 1)
  public void formTest() {
	  System.setProperty("chromedriver", driverPath);
      driver.get(baseUrl);
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[3]")).click();
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/ul[1]/li[1]/span[1]")).click();
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/form[1]/div[1]/div[2]/input[1]")).sendKeys("Jose");
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/form[1]/div[1]/div[4]/input[1]")).sendKeys("Martinez");
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/form[1]/div[2]/div[2]/input[1]")).sendKeys("jose@gmail.com");
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/form[1]/div[5]/div[2]/div[1]/div[1]/input[1]")).sendKeys("02032021");
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/form[1]/div[4]/div[2]/input[1]")).sendKeys("5522334455");
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/form[1]/div[6]/div[2]/div[1]/div[1]/div[1]")).click();
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/form[1]/div[6]/div[2]/div[1]/div[1]/div[1]")).sendKeys("Test");
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/form[1]/div[7]/div[2]/div[1]/label[1]")).click();
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/form[1]/div[9]/div[2]/textarea[1]")).sendKeys("Zurich 27 Zacatecas");
      Select state = new Select(driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/form[1]/div[10]/div[2]/div[1]/div[1]/div[1]/div[1]")));
		state.selectByVisibleText("NCR");
		Select city = new Select(driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/form[1]/div[10]/div[3]/div[1]/div[1]/div[1]")));
		city.selectByVisibleText("Delhi");
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/form[1]/div[11]/div[1]/button[1]")).click();
      driver.findElement(By.xpath("/html[1]/body[1]/div[4]/div[1]/div[1]/div[3]/button[1]")).click();
      driver.close();
	
  }
  @Test(priority = 2)
  public void UpdateTest() {
	  System.out.println("launching chrome browser"); 
	  System.setProperty("chromedriver", driverPath);
      driver = new ChromeDriver();
      driver.get(baseUrl);
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/h5[1]")).click();
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[4]/span[1]")).click();
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/div[2]/div[2]/div[1]/input[1]")).sendKeys("alden@example.com");
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/div[2]/div[2]/div[1]/div[1]/span[1]")).click();
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/div[3]/div[1]/div[2]/div[2]/div[1]/div[7]/div[1]/span[1]")).click();
      driver.findElement(By.xpath("/html[1]/body[1]/div[4]/div[1]/div[1]/div[2]/form[1]/div[1]/div[2]/input[1]")).sendKeys("aldenUpdate");
      driver.findElement(By.xpath("/html[1]/body[1]/div[4]/div[1]/div[1]/div[2]/form[1]/div[2]/div[2]/input[1]")).sendKeys("lastNameUpdate");
      driver.findElement(By.xpath("/html[1]/body[1]/div[4]/div[1]/div[1]/div[2]/form[1]/div[3]/div[2]/input[1]")).sendKeys("aldenupdate@example.com");
      driver.findElement(By.xpath("/html[1]/body[1]/div[4]/div[1]/div[1]/div[2]/form[1]/div[4]/div[2]/input[1]")).sendKeys("28");
      driver.findElement(By.xpath("/html[1]/body[1]/div[4]/div[1]/div[1]/div[2]/form[1]/div[5]/div[2]/input[1]")).sendKeys("2000");
      driver.findElement(By.xpath("/html[1]/body[1]/div[4]/div[1]/div[1]/div[2]/form[1]/div[6]/div[2]/input[1]")).sendKeys("ComplianceUpdate");
      driver.findElement(By.xpath("/html[1]/body[1]/div[4]/div[1]/div[1]/div[2]/form[1]/div[7]/div[1]/button[1]")).click();
       String expectedName = "aldenUpdate";
      WebElement actualTitle = driver.findElement(By.xpath("/html[1]/body[1]/div[4]/div[1]/div[1]/div[2]/form[1]/div[1]/div[2]/input[1]"));
      Assert.assertEquals(actualTitle, expectedName);
      driver.close();
	
  }
  @Test(priority = 3)
  public void AlertTest() {
	  System.out.println("launching chrome browser"); 
	  System.setProperty("chromedriver", driverPath);
      driver = new ChromeDriver();
      driver.get(baseUrl);
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[3]/h5[1]")).click();
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/div[1]/ul[1]/li[2]/span[1]")).click();
      driver.findElement(By.xpath("/html[1]/body[1]/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[2]/button[1]")).click();
      driver.close();
	
  } 

}
